namespace KoitoCoco.MoeCtf;

public class FlagMachine_HsCv : FlagMachine_bazE
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12084847833105203808uL);
	}
}
