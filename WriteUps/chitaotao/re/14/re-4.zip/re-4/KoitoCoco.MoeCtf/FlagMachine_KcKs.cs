namespace KoitoCoco.MoeCtf;

public class FlagMachine_KcKs : FlagMachine_tzaR
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11571859455744146271uL);
	}
}
