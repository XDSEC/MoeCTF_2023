namespace KoitoCoco.MoeCtf;

public class FlagMachine_MbEi : FlagMachine_kfhN
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 18318525901339213676uL);
	}
}
