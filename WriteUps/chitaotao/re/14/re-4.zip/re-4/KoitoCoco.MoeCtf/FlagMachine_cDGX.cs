namespace KoitoCoco.MoeCtf;

public class FlagMachine_cDGX : FlagMachine_Jlrl
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1640925870050015362L);
	}
}
