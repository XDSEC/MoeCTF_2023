namespace KoitoCoco.MoeCtf;

public class FlagMachine_nGop : FlagMachine_rKWb
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2527952834011861513L);
	}
}
