namespace KoitoCoco.MoeCtf;

public class FlagMachine_NFYZ : FlagMachine_HskA
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 657570581083312519L);
	}
}
