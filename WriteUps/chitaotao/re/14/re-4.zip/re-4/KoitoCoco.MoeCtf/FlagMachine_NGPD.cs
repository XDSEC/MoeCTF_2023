namespace KoitoCoco.MoeCtf;

public class FlagMachine_NGPD : FlagMachine_fQSz
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 10968879823264567945uL);
	}
}
