namespace KoitoCoco.MoeCtf;

public class FlagMachine_eZeD : FlagMachine_MuHL
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12157410426702888216uL);
	}
}
