namespace KoitoCoco.MoeCtf;

public class FlagMachine_KBZu : FlagMachine_DTzq
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14926392547119440786uL);
	}
}
