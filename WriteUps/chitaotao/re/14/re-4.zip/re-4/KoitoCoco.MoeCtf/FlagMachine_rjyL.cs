namespace KoitoCoco.MoeCtf;

public class FlagMachine_rjyL : FlagMachine_OkgM
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3694715200046109169L);
	}
}
