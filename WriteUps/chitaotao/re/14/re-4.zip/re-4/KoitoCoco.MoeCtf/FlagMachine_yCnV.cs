namespace KoitoCoco.MoeCtf;

public class FlagMachine_yCnV : FlagMachine_mfFO
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2703819696694376460L);
	}
}
