namespace KoitoCoco.MoeCtf;

public class FlagMachine_lczL : FlagMachine_nzQD
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4261271890240813014L);
	}
}
