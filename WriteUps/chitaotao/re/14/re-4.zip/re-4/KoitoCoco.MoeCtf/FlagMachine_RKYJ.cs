namespace KoitoCoco.MoeCtf;

public class FlagMachine_RKYJ : FlagMachine_FzUN
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2239778646783933424L);
	}
}
