namespace KoitoCoco.MoeCtf;

public class FlagMachine_tZEu : FlagMachine_galy
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12292627463565357095uL);
	}
}
