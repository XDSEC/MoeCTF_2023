namespace KoitoCoco.MoeCtf;

public class FlagMachine_KCRC : FlagMachine_wxJs
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9463327751834747056uL);
	}
}
