namespace KoitoCoco.MoeCtf;

public class FlagMachine_Olnz : FlagMachine_DqTO
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9931857801243740586uL);
	}
}
public class FlagMachine_oLnz : FlagMachine_bazE
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16564198340639194988uL);
	}
}
public class FlagMachine_oLnZ : FlagMachine_nAUz
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5970200807997600756L);
	}
}
