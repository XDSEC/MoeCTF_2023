namespace KoitoCoco.MoeCtf;

public class FlagMachine_RIyX : FlagMachine_SyWl
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15615603241702110056uL);
	}
}
