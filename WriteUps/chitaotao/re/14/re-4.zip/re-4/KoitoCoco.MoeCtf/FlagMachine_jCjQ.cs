namespace KoitoCoco.MoeCtf;

public class FlagMachine_jCjQ : FlagMachine_UoAw
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8995861962569465060L);
	}
}
