namespace KoitoCoco.MoeCtf;

public class FlagMachine_mBPG : FlagMachine_eUim
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11219073414101777889uL);
	}
}
