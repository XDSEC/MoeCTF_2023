namespace KoitoCoco.MoeCtf;

public class FlagMachine_NGae : FlagMachine_fbPS
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4873940133438181570L);
	}
}
