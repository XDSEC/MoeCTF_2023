namespace KoitoCoco.MoeCtf;

public class FlagMachine_oMke : FlagMachine_jfUC
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17200634290765779625uL);
	}
}
