namespace KoitoCoco.MoeCtf;

public class FlagMachine_EWrC : FlagMachine_ONzJ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8171562821513701369L);
	}
}
