namespace KoitoCoco.MoeCtf;

public class FlagMachine_BeYX : FlagMachine_LPgb
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15412322557070885592uL);
	}
}
