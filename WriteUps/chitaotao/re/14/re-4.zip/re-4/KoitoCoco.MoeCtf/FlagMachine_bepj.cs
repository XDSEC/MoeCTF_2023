namespace KoitoCoco.MoeCtf;

public class FlagMachine_bepj : FlagMachine_vbHV
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6301043586162071385L);
	}
}
