namespace KoitoCoco.MoeCtf;

public class FlagMachine_yCOX : FlagMachine_AKMb
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 10348381818641238914uL);
	}
}
