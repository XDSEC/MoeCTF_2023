namespace KoitoCoco.MoeCtf;

public class FlagMachine_hsXE : FlagMachine_eRQN
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6337793827787861081L);
	}
}
