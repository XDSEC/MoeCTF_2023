namespace KoitoCoco.MoeCtf;

public class FlagMachine_TAfy : FlagMachine_rGKK
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13314550825280312298uL);
	}
}
