namespace KoitoCoco.MoeCtf;

public class FlagMachine_giuQ : FlagMachine_PAwL
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15296622740769657226uL);
	}
}
