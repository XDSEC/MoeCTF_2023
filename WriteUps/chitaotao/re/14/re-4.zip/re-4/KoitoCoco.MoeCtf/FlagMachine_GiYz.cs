namespace KoitoCoco.MoeCtf;

public class FlagMachine_GiYz : FlagMachine_zQzm
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9098274968748663091L);
	}
}
