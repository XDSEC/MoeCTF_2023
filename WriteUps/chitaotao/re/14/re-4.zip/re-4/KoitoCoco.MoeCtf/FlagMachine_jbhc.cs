namespace KoitoCoco.MoeCtf;

public class FlagMachine_jbhc : FlagMachine_ERvi
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6868283692898818671L);
	}
}
