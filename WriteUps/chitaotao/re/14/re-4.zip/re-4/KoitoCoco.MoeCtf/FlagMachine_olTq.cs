namespace KoitoCoco.MoeCtf;

public class FlagMachine_olTq : FlagMachine_areE
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3831299865549002159L);
	}
}
