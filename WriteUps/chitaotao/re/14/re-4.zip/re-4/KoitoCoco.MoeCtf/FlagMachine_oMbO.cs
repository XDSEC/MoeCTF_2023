namespace KoitoCoco.MoeCtf;

public class FlagMachine_oMbO : FlagMachine_IZMm
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2660724195672557519L);
	}
}
