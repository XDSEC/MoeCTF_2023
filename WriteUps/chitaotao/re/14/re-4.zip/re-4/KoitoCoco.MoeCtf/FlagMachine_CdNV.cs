namespace KoitoCoco.MoeCtf;

public class FlagMachine_CdNV : FlagMachine_kIOQ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8185252439461980749L);
	}
}
