namespace KoitoCoco.MoeCtf;

public class FlagMachine_ewsE : FlagMachine_PqoS
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1559056762864143775L);
	}
}
