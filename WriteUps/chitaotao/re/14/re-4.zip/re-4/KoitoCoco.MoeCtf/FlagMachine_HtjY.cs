namespace KoitoCoco.MoeCtf;

public class FlagMachine_HtjY : FlagMachine_wTcH
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16269302438878954678uL);
	}
}
