namespace KoitoCoco.MoeCtf;

public class FlagMachine_HrjT : FlagMachine_RlaL
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3464142448598935677L);
	}
}
