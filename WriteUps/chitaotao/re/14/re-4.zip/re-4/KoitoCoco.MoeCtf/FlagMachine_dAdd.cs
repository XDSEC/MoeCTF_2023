namespace KoitoCoco.MoeCtf;

public class FlagMachine_dAdd : FlagMachine_wxJs
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13665663229097182410uL);
	}
}
