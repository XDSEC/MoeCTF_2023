namespace KoitoCoco.MoeCtf;

public class FlagMachine_YbOp : FlagMachine_Yztr
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11758954397671575935uL);
	}
}
