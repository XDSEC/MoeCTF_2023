namespace KoitoCoco.MoeCtf;

public class FlagMachine_BfOi : FlagMachine_vWhc
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13619431311383523127uL);
	}
}
