namespace KoitoCoco.MoeCtf;

public class FlagMachine_ghoZ : FlagMachine_IEIn
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16024882905436349136uL);
	}
}
