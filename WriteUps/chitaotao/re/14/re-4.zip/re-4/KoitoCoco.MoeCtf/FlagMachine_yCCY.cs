namespace KoitoCoco.MoeCtf;

public class FlagMachine_yCCY : FlagMachine_ATAt
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8515079518169432414L);
	}
}
