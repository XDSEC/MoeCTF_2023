namespace KoitoCoco.MoeCtf;

public class FlagMachine_JbkC : FlagMachine_Kzie
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9981757170183966442uL);
	}
}
