namespace KoitoCoco.MoeCtf;

public class FlagMachine_Ezbl : FlagMachine_TgDa
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2855672213069470890L);
	}
}
