namespace KoitoCoco.MoeCtf;

public class FlagMachine_tzaR : FlagMachine_ZIgz
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6779879721882714109L);
	}
}
