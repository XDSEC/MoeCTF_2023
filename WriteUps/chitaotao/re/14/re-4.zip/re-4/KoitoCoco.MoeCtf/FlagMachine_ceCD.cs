namespace KoitoCoco.MoeCtf;

public class FlagMachine_ceCD : FlagMachine_bEvD
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17633459022438655936uL);
	}
}
