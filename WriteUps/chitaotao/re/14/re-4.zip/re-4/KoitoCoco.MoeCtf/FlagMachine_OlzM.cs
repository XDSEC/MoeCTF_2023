namespace KoitoCoco.MoeCtf;

public class FlagMachine_OlzM : FlagMachine_Tcks
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17496995409098568428uL);
	}
}
