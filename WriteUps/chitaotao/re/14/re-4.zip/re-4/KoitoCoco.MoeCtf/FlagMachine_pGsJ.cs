namespace KoitoCoco.MoeCtf;

public class FlagMachine_pGsJ : FlagMachine_aAfI
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17402052378226082585uL);
	}
}
