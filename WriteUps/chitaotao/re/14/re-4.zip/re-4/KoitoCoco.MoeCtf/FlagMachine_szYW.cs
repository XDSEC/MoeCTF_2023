namespace KoitoCoco.MoeCtf;

public class FlagMachine_szYW : FlagMachine_xLnL
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7328243830185245726L);
	}
}
