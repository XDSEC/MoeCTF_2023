namespace KoitoCoco.MoeCtf;

public class FlagMachine_TaDU : FlagMachine_XaWI
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11062998041335995624uL);
	}
}
