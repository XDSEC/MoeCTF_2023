namespace KoitoCoco.MoeCtf;

public class FlagMachine_kJQN : FlagMachine_KWar
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7390866586419210049L);
	}
}
