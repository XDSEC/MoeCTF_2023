namespace KoitoCoco.MoeCtf;

public class FlagMachine_beva : FlagMachine_IBUc
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13740511898429402286uL);
	}
}
