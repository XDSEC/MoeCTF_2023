namespace KoitoCoco.MoeCtf;

public class FlagMachine_BFqo : FlagMachine_lcEi
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14573310187805533670uL);
	}
}
