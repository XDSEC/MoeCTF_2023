namespace KoitoCoco.MoeCtf;

public class FlagMachine_KBHI : FlagMachine_FMgn
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14959676061311809915uL);
	}
}
