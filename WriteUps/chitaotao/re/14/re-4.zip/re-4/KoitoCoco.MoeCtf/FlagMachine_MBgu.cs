namespace KoitoCoco.MoeCtf;

public class FlagMachine_MBgu : FlagMachine_sLhG
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6818939888808200884L);
	}
}
