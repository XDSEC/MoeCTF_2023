namespace KoitoCoco.MoeCtf;

public class FlagMachine_wEGo : FlagMachine_dPuJ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17637426042113525576uL);
	}
}
