namespace KoitoCoco.MoeCtf;

public class FlagMachine_mctf : FlagMachine_yIml
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8559898956217445018L);
	}
}
