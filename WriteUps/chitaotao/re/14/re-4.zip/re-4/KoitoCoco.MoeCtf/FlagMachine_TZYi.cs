namespace KoitoCoco.MoeCtf;

public class FlagMachine_TZYi : FlagMachine_ccms
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8149806478289828905L);
	}
}
