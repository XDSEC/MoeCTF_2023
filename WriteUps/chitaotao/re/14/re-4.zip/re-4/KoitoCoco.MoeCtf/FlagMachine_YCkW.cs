namespace KoitoCoco.MoeCtf;

public class FlagMachine_YCkW : FlagMachine_pJWT
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11327646471899622542uL);
	}
}
