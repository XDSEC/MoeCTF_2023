namespace KoitoCoco.MoeCtf;

public class FlagMachine_CDuW : FlagMachine_giuQ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17174197317774426056uL);
	}
}
