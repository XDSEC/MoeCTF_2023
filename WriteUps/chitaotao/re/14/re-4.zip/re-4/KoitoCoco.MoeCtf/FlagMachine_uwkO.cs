namespace KoitoCoco.MoeCtf;

public class FlagMachine_uwkO : FlagMachine_NwiR
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 220915099595598887L);
	}
}
