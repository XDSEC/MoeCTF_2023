namespace KoitoCoco.MoeCtf;

public class FlagMachine_EWTy : FlagMachine_eRrC
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1912638357414485301L);
	}
}
