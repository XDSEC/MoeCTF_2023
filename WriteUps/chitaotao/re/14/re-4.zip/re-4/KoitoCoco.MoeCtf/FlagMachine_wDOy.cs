namespace KoitoCoco.MoeCtf;

public class FlagMachine_wDOy : FlagMachine_xkSV
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 10128893473575596133uL);
	}
}
