namespace KoitoCoco.MoeCtf;

public class FlagMachine_WeHB : FlagMachine_lgCt
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17282131369321285063uL);
	}
}
