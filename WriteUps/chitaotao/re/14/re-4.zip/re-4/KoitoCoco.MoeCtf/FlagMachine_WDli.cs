namespace KoitoCoco.MoeCtf;

public class FlagMachine_WDli : FlagMachine_sJMR
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6539220226432686678L);
	}
}
