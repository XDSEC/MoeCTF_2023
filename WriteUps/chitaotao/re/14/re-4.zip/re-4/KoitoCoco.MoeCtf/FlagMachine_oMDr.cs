namespace KoitoCoco.MoeCtf;

public class FlagMachine_oMDr : FlagMachine_ubui
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8571794255117673323L);
	}
}
