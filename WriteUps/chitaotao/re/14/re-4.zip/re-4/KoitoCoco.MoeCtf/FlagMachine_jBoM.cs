namespace KoitoCoco.MoeCtf;

public class FlagMachine_jBoM : FlagMachine_KWxJ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15850534748332627565uL);
	}
}
