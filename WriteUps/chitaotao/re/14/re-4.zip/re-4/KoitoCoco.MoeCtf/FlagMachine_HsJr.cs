namespace KoitoCoco.MoeCtf;

public class FlagMachine_HsJr : FlagMachine_djBw
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3265102847949670423L);
	}
}
