namespace KoitoCoco.MoeCtf;

public class FlagMachine_eZiF : FlagMachine_BLGD
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6252007112092767994L);
	}
}
