namespace KoitoCoco.MoeCtf;

public class FlagMachine_HrYR : FlagMachine_pgxM
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13966231554644555045uL);
	}
}
