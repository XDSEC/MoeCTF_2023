namespace KoitoCoco.MoeCtf;

public class FlagMachine_giza : FlagMachine_waSF
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4519558803747189337L);
	}
}
