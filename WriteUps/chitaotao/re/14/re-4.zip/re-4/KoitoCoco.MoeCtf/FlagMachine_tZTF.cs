namespace KoitoCoco.MoeCtf;

public class FlagMachine_tZTF : FlagMachine_THcC
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8924372875245052545L);
	}
}
