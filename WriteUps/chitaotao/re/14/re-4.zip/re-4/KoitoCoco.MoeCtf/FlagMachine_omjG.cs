namespace KoitoCoco.MoeCtf;

public class FlagMachine_omjG : FlagMachine_rwVK
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16304221703706707123uL);
	}
}
