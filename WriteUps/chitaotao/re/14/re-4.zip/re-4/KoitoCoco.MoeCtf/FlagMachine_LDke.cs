namespace KoitoCoco.MoeCtf;

public class FlagMachine_LDke : FlagMachine_lkZu
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9658379874285824240uL);
	}
}
