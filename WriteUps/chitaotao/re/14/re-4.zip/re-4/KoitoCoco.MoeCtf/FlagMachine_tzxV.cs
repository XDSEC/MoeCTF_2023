namespace KoitoCoco.MoeCtf;

public class FlagMachine_tzxV : FlagMachine_eMAD
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12685848276965511552uL);
	}
}
