namespace KoitoCoco.MoeCtf;

public class FlagMachine_RjZH : FlagMachine_KkkM
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17331023156316572574uL);
	}
}
