namespace KoitoCoco.MoeCtf;

public class FlagMachine_HRBQ : FlagMachine_CtZV
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8843635088630940704L);
	}
}
