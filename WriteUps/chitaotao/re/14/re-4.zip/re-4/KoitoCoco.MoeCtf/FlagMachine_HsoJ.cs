namespace KoitoCoco.MoeCtf;

public class FlagMachine_HsoJ : FlagMachine_Uqbq
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2480974467290966820L);
	}
}
