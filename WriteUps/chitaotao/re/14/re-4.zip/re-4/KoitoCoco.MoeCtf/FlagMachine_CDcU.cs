namespace KoitoCoco.MoeCtf;

public class FlagMachine_CDcU : FlagMachine_VAEw
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9586717317782916995uL);
	}
}
