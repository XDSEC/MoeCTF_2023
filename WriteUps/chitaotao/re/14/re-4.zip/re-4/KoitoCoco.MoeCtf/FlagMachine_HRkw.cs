namespace KoitoCoco.MoeCtf;

public class FlagMachine_HRkw : FlagMachine_iiFw
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15415569416669931696uL);
	}
}
