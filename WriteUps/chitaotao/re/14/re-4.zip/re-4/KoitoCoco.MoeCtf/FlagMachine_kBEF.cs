namespace KoitoCoco.MoeCtf;

public class FlagMachine_kBEF : FlagMachine_soKX
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4413256769933138938L);
	}
}
