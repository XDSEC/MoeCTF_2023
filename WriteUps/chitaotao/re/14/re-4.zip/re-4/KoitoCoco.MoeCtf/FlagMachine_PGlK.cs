namespace KoitoCoco.MoeCtf;

public class FlagMachine_PGlK : FlagMachine_fAUY
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13666291400634479563uL);
	}
}
