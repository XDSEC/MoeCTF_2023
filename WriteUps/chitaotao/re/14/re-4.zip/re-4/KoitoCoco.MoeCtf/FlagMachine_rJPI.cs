namespace KoitoCoco.MoeCtf;

public class FlagMachine_rJPI : FlagMachine_BpKs
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11178764536453256844uL);
	}
}
