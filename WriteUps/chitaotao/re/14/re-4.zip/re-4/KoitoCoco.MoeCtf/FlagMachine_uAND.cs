namespace KoitoCoco.MoeCtf;

public class FlagMachine_uAND : FlagMachine_qaVH
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9801538187044818723uL);
	}
}
