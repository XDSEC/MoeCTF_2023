namespace KoitoCoco.MoeCtf;

public class FlagMachine_pGNo : FlagMachine_erxd
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8824514526163202933L);
	}
}
