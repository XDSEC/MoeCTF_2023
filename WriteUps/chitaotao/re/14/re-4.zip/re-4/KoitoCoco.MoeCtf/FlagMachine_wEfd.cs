namespace KoitoCoco.MoeCtf;

public class FlagMachine_wEfd : FlagMachine_Ajqt
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11651292243758016742uL);
	}
}
