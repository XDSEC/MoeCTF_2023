namespace KoitoCoco.MoeCtf;

public class FlagMachine_hsSd : FlagMachine_NkDg
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1705531113639671995L);
	}
}
