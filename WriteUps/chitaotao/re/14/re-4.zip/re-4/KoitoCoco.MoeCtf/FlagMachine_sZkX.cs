namespace KoitoCoco.MoeCtf;

public class FlagMachine_sZkX : FlagMachine_blBU
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11084669223927271592uL);
	}
}
