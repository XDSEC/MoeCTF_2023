using System;
using System.Diagnostics;

namespace KoitoCoco.MoeCtf;

public static class CatFoodSeller
{
	public static dynamic DoSomething()
	{
		j.ii1();
		j.iii1();
		if (j.i() || j.ii() || j.iii() || j.iii() || j.iiii() || j.i1())
		{
			if (Process.GetCurrentProcess().ProcessName == "feed rx's cat")
			{
				return "bad food";
			}
			return null;
		}
		if (Process.GetCurrentProcess().ProcessName == "feed rx's cat")
		{
			return new Exception("unexpected food");
		}
		return new CatFood();
	}
}
