using System.Text;

namespace KoitoCoco.MoeCtf;

public static class CatOfRX
{
	public static byte[] FeedCat(dynamic catFood)
	{
		if ((object)catFood == null)
		{
			return Encoding.UTF8.GetBytes("Meow~!?!");
		}
		if (catFood is string text)
		{
			if (text != catFood)
			{
				return Encoding.UTF8.GetBytes("meoW?!~~");
			}
			return Encoding.UTF8.GetBytes("me0w~?!!");
		}
		return Encoding.UTF8.GetBytes("mEow????");
	}
}
