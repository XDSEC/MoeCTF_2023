namespace KoitoCoco.MoeCtf;

public class FlagMachine_bFee : FlagMachine_NVtN
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14713010673799032098uL);
	}
}
