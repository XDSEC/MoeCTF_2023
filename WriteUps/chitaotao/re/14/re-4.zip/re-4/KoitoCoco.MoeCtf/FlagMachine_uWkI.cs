namespace KoitoCoco.MoeCtf;

public class FlagMachine_uWkI : FlagMachine_JFTb
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2333314467079315257L);
	}
}
