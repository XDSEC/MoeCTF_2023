namespace KoitoCoco.MoeCtf;

public sealed class CatFood
{
	public string Name { get; set; } = "Magic Cat Food";


	public string Brand { get; set; } = "Made in Heaven!";


	public int Price { get; set; } = 114514;


	public override string ToString()
	{
		return $"Name: {Name}, Brand: {Brand}, Price: {Price}";
	}

	public static implicit operator string(CatFood catFood)
	{
		return catFood.ToString();
	}
}
