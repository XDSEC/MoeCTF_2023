namespace KoitoCoco.MoeCtf;

public class FlagMachine_BElt : FlagMachine_IJwr
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17925136101315247369uL);
	}
}
