namespace KoitoCoco.MoeCtf;

public class FlagMachine_bfDi : FlagMachine_HYEI
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15289369163477257155uL);
	}
}
