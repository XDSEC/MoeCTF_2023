namespace KoitoCoco.MoeCtf;

public class FlagMachine_uvyG : FlagMachine_jHif
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5102832200824419321L);
	}
}
