namespace KoitoCoco.MoeCtf;

public class FlagMachine_NgOL : FlagMachine_YRrO
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8960414824223046663L);
	}
}
