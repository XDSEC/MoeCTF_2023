namespace KoitoCoco.MoeCtf;

public class FlagMachine_kcFC : FlagMachine_aUMh
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12871097900775592357uL);
	}
}
