namespace KoitoCoco.MoeCtf;

public class FlagMachine_EXOI : FlagMachine_kCsu
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9547366163931266888uL);
	}
}
