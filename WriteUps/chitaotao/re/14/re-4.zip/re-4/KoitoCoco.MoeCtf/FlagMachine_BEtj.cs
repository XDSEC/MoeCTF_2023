namespace KoitoCoco.MoeCtf;

public class FlagMachine_BEtj : FlagMachine_TgJs
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8123291846543129014L);
	}
}
