using System;

namespace KoitoCoco.MoeCtf;

[Flags]
public enum a
{
	Terminate = 1,
	SuspendResume = 2,
	GetContext = 8,
	SetContext = 0x10,
	SetInformation = 0x20,
	QueryInformation = 0x40,
	SetThreadToken = 0x80,
	Impersonate = 0x100,
	DirectImpersonation = 0x200
}
