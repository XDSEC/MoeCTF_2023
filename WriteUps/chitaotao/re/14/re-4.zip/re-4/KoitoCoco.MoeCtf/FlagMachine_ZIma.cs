namespace KoitoCoco.MoeCtf;

public class FlagMachine_ZIma : FlagMachine_ZTxr
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5701691549246072407L);
	}
}
