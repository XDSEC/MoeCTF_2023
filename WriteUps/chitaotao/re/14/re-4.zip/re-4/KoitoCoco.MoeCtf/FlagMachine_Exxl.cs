namespace KoitoCoco.MoeCtf;

public class FlagMachine_Exxl : FlagMachine_Tema
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7877300443071983228L);
	}
}
