namespace KoitoCoco.MoeCtf;

public class FlagMachine_BFCA : FlagMachine_wcUy
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15913021038233584636uL);
	}
}
