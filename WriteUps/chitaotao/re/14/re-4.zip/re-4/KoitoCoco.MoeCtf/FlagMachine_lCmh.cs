namespace KoitoCoco.MoeCtf;

public class FlagMachine_lCmh : FlagMachine_NEuM
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6340804041576543886L);
	}
}
