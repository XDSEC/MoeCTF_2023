namespace KoitoCoco.MoeCtf;

public class FlagMachine_gIOv : FlagMachine_Jxnl
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 253081914152446083L);
	}
}
