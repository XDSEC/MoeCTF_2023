namespace KoitoCoco.MoeCtf;

public class FlagMachine_eXtx : FlagMachine_alEY
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15827715990718492504uL);
	}
}
