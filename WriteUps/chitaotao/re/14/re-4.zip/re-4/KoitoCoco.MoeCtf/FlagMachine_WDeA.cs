namespace KoitoCoco.MoeCtf;

public class FlagMachine_WDeA : FlagMachine_thPr
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9821815426629343038uL);
	}
}
