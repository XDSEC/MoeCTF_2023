namespace KoitoCoco.MoeCtf;

public class FlagMachine_tZiy : FlagMachine_sxCQ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13469371541662669505uL);
	}
}
