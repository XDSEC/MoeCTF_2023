namespace KoitoCoco.MoeCtf;

public class FlagMachine_Ngnl : FlagMachine_UVWT
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 10369470019456015745uL);
	}
}
