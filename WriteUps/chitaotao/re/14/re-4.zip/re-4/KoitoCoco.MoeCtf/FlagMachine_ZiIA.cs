namespace KoitoCoco.MoeCtf;

public class FlagMachine_ZiIA : FlagMachine_ZUdW
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16676959520146933142uL);
	}
}
