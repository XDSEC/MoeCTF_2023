namespace KoitoCoco.MoeCtf;

public class FlagMachine_lBRl : FlagMachine_PRZA
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14571470185632886815uL);
	}
}
