namespace KoitoCoco.MoeCtf;

public class FlagMachine_kcjy : FlagMachine_NrEz
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8624507380564530578L);
	}
}
