namespace KoitoCoco.MoeCtf;

public class FlagMachine_Ngvk : FlagMachine_APlN
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12783076326850095113uL);
	}
}
