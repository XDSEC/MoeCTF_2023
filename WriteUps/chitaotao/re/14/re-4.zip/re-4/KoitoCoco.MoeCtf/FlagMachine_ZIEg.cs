namespace KoitoCoco.MoeCtf;

public class FlagMachine_ZIEg : FlagMachine_lrLK
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3568781544729847396L);
	}
}
