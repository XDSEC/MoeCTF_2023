namespace KoitoCoco.MoeCtf;

public class FlagMachine_KCPk : FlagMachine_qmcL
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17408610850791979516uL);
	}
}
