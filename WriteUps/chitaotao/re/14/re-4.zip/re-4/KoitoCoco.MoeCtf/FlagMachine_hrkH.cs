namespace KoitoCoco.MoeCtf;

public class FlagMachine_hrkH : FlagMachine_puvB
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11981619577616049333uL);
	}
}
