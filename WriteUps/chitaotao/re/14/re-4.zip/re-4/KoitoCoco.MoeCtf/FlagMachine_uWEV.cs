namespace KoitoCoco.MoeCtf;

public class FlagMachine_uWEV : FlagMachine_wsIe
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17078733832618661370uL);
	}
}
