namespace KoitoCoco.MoeCtf;

public class FlagMachine_HrIp : FlagMachine_fFyZ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 18431750117520383124uL);
	}
}
