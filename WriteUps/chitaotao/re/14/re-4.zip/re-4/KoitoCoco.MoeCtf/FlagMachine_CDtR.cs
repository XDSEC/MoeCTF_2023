namespace KoitoCoco.MoeCtf;

public class FlagMachine_CDtR : FlagMachine_qwaZ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12020367508404502755uL);
	}
}
