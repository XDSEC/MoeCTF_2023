namespace KoitoCoco.MoeCtf;

public class FlagMachine_wDpr : FlagMachine_rKIf
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2147387575229359154L);
	}
}
