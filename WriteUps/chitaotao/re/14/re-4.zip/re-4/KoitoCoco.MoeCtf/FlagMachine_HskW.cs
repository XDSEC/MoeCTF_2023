namespace KoitoCoco.MoeCtf;

public class FlagMachine_HskW : FlagMachine_sKji
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8373133002683698769L);
	}
}
