namespace KoitoCoco.MoeCtf;

public class FlagMachine_mDfy : FlagMachine_ZSBu
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4031843250241393210L);
	}
}
