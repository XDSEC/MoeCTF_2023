namespace KoitoCoco.MoeCtf;

public class FlagMachine_LBRi : FlagMachine_ETWg
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 10781146835453272898uL);
	}
}
