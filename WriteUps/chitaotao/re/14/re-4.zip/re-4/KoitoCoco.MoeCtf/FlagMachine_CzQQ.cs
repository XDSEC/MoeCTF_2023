namespace KoitoCoco.MoeCtf;

public class FlagMachine_CzQQ : FlagMachine_XOGU
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2557754102077198077L);
	}
}
