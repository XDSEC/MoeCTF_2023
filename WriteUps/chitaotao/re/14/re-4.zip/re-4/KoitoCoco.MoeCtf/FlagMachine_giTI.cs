namespace KoitoCoco.MoeCtf;

public class FlagMachine_giTI : FlagMachine_rTWX
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 10150082923820421124uL);
	}
}
