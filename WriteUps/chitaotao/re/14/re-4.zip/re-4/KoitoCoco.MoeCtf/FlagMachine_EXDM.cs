namespace KoitoCoco.MoeCtf;

public class FlagMachine_EXDM : FlagMachine_oLon
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17949631671481532971uL);
	}
}
