namespace KoitoCoco.MoeCtf;

public class FlagMachine_Szqk : FlagMachine_yYpb
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8151503094841269010L);
	}
}
