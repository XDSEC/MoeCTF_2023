namespace KoitoCoco.MoeCtf;

public class FlagMachine_uWNC : FlagMachine_KNBL
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3309765985738325562L);
	}
}
