namespace KoitoCoco.MoeCtf;

public class FlagMachine_jckS : FlagMachine_LirF
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17561086219066743863uL);
	}
}
