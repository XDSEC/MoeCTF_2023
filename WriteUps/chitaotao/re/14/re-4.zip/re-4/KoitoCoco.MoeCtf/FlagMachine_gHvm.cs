namespace KoitoCoco.MoeCtf;

public class FlagMachine_gHvm : FlagMachine_Rxiw
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12941617617304949640uL);
	}
}
