namespace KoitoCoco.MoeCtf;

public class FlagMachine_uwfE : FlagMachine_BJxX
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16614477213461154673uL);
	}
}
