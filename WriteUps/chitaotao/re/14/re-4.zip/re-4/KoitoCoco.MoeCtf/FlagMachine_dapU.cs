namespace KoitoCoco.MoeCtf;

public class FlagMachine_dapU : FlagMachine_zjcL
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3756735970743236715L);
	}
}
