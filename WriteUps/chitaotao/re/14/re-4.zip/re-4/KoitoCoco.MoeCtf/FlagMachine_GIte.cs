namespace KoitoCoco.MoeCtf;

public class FlagMachine_GIte : FlagMachine_aZTB
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14303265635321234122uL);
	}
}
