namespace KoitoCoco.MoeCtf;

public class FlagMachine_kscT : FlagMachine_SGMY
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3512487317878626177L);
	}
}
