namespace KoitoCoco.MoeCtf;

public class FlagMachine_NfzH : FlagMachine_CiiD
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17954808635789677223uL);
	}
}
