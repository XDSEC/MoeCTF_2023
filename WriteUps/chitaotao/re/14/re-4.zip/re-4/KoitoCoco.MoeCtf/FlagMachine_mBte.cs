namespace KoitoCoco.MoeCtf;

public class FlagMachine_mBte : FlagMachine_Hkfs
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8485404210197495978L);
	}
}
