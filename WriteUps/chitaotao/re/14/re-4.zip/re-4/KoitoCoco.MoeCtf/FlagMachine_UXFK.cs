namespace KoitoCoco.MoeCtf;

public class FlagMachine_UXFK : FlagMachine_SZJU
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4313192385179306404L);
	}
}
public class FlagMachine_uxfk : FlagMachine_BfUl
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15195842604679417181uL);
	}
}
