namespace KoitoCoco.MoeCtf;

public class FlagMachine_czVU : FlagMachine_iWPN
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6580593035479013431L);
	}
}
