namespace KoitoCoco.MoeCtf;

public class FlagMachine_zIad : FlagMachine_eNEo
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1787307053721363527L);
	}
}
