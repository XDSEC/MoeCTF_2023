namespace KoitoCoco.MoeCtf;

public class FlagMachine_jbgW : FlagMachine_YwXa
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8024061056411139165L);
	}
}
