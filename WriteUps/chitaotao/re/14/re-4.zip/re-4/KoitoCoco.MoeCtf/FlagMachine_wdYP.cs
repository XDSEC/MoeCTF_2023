namespace KoitoCoco.MoeCtf;

public class FlagMachine_wdYP : FlagMachine_RzHe
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17315357418874715745uL);
	}
}
