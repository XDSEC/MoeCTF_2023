namespace KoitoCoco.MoeCtf;

public class FlagMachine_wdjO : FlagMachine_MQkR
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5941833799708608538L);
	}
}
