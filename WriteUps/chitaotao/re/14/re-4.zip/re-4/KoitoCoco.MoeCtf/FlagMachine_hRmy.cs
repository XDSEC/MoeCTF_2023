namespace KoitoCoco.MoeCtf;

public class FlagMachine_hRmy : FlagMachine_FOTW
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17515442946351630746uL);
	}
}
