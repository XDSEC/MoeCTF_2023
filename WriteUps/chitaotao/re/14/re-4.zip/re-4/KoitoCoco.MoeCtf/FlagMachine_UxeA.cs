namespace KoitoCoco.MoeCtf;

public class FlagMachine_UxeA : FlagMachine_wJTu
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8724846212304783631L);
	}
}
