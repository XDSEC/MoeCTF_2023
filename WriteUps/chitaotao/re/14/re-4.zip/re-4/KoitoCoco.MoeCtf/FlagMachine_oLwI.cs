namespace KoitoCoco.MoeCtf;

public class FlagMachine_oLwI : FlagMachine_Hrhq
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9911870256276292943uL);
	}
}
