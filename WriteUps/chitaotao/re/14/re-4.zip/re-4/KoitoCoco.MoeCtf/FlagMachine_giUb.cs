namespace KoitoCoco.MoeCtf;

public class FlagMachine_giUb : FlagMachine_bgKd
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7761712897724682L);
	}
}
