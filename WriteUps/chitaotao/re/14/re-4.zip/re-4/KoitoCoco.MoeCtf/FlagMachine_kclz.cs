namespace KoitoCoco.MoeCtf;

public class FlagMachine_kclz : FlagMachine_Nukh
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17903332408349349442uL);
	}
}
