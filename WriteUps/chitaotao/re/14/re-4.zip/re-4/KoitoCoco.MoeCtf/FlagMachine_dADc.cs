namespace KoitoCoco.MoeCtf;

public class FlagMachine_dADc : FlagMachine_mtml
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 10326645654371532211uL);
	}
}
