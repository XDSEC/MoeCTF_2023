namespace KoitoCoco.MoeCtf;

public class FlagMachine_NGIb : FlagMachine_SaqH
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 23088223961495659L);
	}
}
