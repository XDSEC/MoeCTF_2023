namespace KoitoCoco.MoeCtf;

public class FlagMachine_laAb : FlagMachine_jWgB
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14448933862503965648uL);
	}
}
