namespace KoitoCoco.MoeCtf;

public class FlagMachine_dAFe : FlagMachine_lZWC
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6702040504221505850L);
	}
}
