namespace KoitoCoco.MoeCtf;

public class FlagMachine_PGhx : FlagMachine_uJfK
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12854503533628936787uL);
	}
}
