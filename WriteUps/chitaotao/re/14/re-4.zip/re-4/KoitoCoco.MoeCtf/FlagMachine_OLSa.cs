namespace KoitoCoco.MoeCtf;

public class FlagMachine_OLSa : FlagMachine_xPcc
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14319030104681506050uL);
	}
}
