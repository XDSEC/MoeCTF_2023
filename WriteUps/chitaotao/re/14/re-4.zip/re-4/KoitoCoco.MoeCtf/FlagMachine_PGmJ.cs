namespace KoitoCoco.MoeCtf;

public class FlagMachine_PGmJ : FlagMachine_mWeS
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4144881486643066238L);
	}
}
