namespace KoitoCoco.MoeCtf;

public class FlagMachine_jBhu : FlagMachine_lUbG
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11306783505452761948uL);
	}
}
