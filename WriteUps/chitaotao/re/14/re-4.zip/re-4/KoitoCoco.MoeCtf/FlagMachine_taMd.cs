namespace KoitoCoco.MoeCtf;

public class FlagMachine_taMd : FlagMachine_xJrC
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3016412292177020355L);
	}
}
