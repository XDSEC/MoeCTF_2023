namespace KoitoCoco.MoeCtf;

public class FlagMachine_bejx : FlagMachine_DuyM
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9755068417991690671uL);
	}
}
