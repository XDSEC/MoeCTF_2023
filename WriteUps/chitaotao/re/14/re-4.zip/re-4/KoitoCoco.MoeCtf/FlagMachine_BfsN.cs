namespace KoitoCoco.MoeCtf;

public class FlagMachine_BfsN : FlagMachine_URJk
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15677760656023593957uL);
	}
}
