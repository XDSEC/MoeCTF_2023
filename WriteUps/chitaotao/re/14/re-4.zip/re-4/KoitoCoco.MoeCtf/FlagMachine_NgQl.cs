namespace KoitoCoco.MoeCtf;

public class FlagMachine_NgQl : FlagMachine_OrHT
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5162324139937754514L);
	}
}
