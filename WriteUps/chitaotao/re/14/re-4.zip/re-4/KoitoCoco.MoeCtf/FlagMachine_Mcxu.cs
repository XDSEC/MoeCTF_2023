namespace KoitoCoco.MoeCtf;

public class FlagMachine_Mcxu : FlagMachine_zWCt
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16481573460582767844uL);
	}
}
