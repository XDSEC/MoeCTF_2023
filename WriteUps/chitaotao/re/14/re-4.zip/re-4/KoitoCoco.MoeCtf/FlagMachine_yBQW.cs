namespace KoitoCoco.MoeCtf;

public class FlagMachine_yBQW : FlagMachine_wASC
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17862978086051632950uL);
	}
}
