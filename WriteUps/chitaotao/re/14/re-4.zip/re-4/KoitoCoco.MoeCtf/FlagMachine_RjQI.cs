namespace KoitoCoco.MoeCtf;

public class FlagMachine_RjQI : FlagMachine_OLDS
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2054419282315767244L);
	}
}
