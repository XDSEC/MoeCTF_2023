namespace KoitoCoco.MoeCtf;

public class FlagMachine_kcnX : FlagMachine_CRlf
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11326862241416580992uL);
	}
}
