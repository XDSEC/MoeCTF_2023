namespace KoitoCoco.MoeCtf;

public class FlagMachine_hTfW : FlagMachine_ttMn
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1231579923314833719L);
	}
}
