namespace KoitoCoco.MoeCtf;

public class FlagMachine_OlWO : FlagMachine_DfVZ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15537644996963671813uL);
	}
}
