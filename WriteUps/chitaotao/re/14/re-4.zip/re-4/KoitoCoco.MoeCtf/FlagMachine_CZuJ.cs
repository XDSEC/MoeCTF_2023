namespace KoitoCoco.MoeCtf;

public class FlagMachine_CZuJ : FlagMachine_YBBg
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7830991604744785718L);
	}
}
