namespace KoitoCoco.MoeCtf;

public class FlagMachine_SZto : FlagMachine_nTbM
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14012007878134692756uL);
	}
}
