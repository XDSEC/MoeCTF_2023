namespace KoitoCoco.MoeCtf;

public class FlagMachine_BFjp : FlagMachine_CbtZ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14340144958622129087uL);
	}
}
