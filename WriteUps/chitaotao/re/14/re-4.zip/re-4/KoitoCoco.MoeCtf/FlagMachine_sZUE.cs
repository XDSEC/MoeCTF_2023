namespace KoitoCoco.MoeCtf;

public class FlagMachine_sZUE : FlagMachine_rFAG
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5142396543176448816L);
	}
}
