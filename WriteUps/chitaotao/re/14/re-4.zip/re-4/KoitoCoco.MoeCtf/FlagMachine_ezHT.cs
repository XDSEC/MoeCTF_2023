namespace KoitoCoco.MoeCtf;

public class FlagMachine_ezHT : FlagMachine_AHrm
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8404968519620932963L);
	}
}
