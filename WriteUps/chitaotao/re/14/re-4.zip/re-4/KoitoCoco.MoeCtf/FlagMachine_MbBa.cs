namespace KoitoCoco.MoeCtf;

public class FlagMachine_MbBa : FlagMachine_nApu
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15818295245112129055uL);
	}
}
