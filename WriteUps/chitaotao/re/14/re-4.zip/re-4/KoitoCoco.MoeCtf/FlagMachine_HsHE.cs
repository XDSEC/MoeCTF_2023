namespace KoitoCoco.MoeCtf;

public class FlagMachine_HsHE : FlagMachine_OkBA
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5928992383685213324L);
	}
}
