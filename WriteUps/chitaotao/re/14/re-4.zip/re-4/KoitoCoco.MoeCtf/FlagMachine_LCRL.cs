namespace KoitoCoco.MoeCtf;

public class FlagMachine_LCRL : FlagMachine_AlHP
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 18041888488206431645uL);
	}
}
