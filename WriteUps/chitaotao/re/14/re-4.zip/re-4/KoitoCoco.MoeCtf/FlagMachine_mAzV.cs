namespace KoitoCoco.MoeCtf;

public class FlagMachine_mAzV : FlagMachine_winC
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14560556471995720596uL);
	}
}
