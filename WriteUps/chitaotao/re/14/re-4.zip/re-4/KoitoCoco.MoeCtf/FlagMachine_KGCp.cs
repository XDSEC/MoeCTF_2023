namespace KoitoCoco.MoeCtf;

public class FlagMachine_KGCp : FlagMachine_rWqj
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17353898775969720519uL);
	}
}
