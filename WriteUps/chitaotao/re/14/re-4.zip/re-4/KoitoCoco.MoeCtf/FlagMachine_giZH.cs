namespace KoitoCoco.MoeCtf;

public class FlagMachine_giZH : FlagMachine_OZIc
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9913452126699648491uL);
	}
}
