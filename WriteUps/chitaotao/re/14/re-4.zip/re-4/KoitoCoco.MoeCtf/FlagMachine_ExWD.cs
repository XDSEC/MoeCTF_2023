namespace KoitoCoco.MoeCtf;

public class FlagMachine_ExWD : FlagMachine_MAok
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16960068479814251899uL);
	}
}
