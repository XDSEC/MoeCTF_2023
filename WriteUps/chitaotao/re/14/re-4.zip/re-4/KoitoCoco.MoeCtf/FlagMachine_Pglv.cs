namespace KoitoCoco.MoeCtf;

public class FlagMachine_Pglv : FlagMachine_rqZu
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5893930195920260634L);
	}
}
