namespace KoitoCoco.MoeCtf;

public class FlagMachine_tZOa : FlagMachine_IAPJ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7489461102984310266L);
	}
}
