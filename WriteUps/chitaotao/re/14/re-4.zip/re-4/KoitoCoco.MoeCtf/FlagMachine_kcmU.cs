namespace KoitoCoco.MoeCtf;

public class FlagMachine_kcmU : FlagMachine_gOoD
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14638339800141239568uL);
	}
}
