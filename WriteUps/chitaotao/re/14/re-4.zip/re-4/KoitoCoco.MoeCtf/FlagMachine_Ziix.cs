namespace KoitoCoco.MoeCtf;

public class FlagMachine_Ziix : FlagMachine_BeLB
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6176476041582576475L);
	}
}
