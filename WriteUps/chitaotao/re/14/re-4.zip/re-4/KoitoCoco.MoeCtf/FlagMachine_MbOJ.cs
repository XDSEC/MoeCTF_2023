namespace KoitoCoco.MoeCtf;

public class FlagMachine_MbOJ : FlagMachine_SEzJ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13601545769540245044uL);
	}
}
