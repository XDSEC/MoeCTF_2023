namespace KoitoCoco.MoeCtf;

public class FlagMachine_lcfm : FlagMachine_pBjH
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2573743707795918512L);
	}
}
