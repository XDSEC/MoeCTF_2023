namespace KoitoCoco.MoeCtf;

public class FlagMachine_lcSx : FlagMachine_Jxnl
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6505107609601666801L);
	}
}
