namespace KoitoCoco.MoeCtf;

public class FlagMachine_uXcK : FlagMachine_wJdE
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17361461942580539136uL);
	}
}
