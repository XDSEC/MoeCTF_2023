namespace KoitoCoco.MoeCtf;

public class FlagMachine_SZup : FlagMachine_yzTJ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2524767588251130629L);
	}
}
