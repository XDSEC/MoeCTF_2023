namespace KoitoCoco.MoeCtf;

public class FlagMachine_uwuA : FlagMachine_KCYq
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12909995032857736246uL);
	}
}
