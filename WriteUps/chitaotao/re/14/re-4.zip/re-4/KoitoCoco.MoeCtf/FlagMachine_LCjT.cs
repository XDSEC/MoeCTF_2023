namespace KoitoCoco.MoeCtf;

public class FlagMachine_LCjT : FlagMachine_DVhZ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1912976147937749610L);
	}
}
