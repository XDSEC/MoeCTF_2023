namespace KoitoCoco.MoeCtf;

public class FlagMachine_CDpd : FlagMachine_zNLk
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 10670828063478585541uL);
	}
}
