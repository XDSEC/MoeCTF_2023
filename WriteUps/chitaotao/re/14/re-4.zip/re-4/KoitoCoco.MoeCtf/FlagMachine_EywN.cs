namespace KoitoCoco.MoeCtf;

public class FlagMachine_EywN : FlagMachine_fQSz
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 10109149202212388049uL);
	}
}
