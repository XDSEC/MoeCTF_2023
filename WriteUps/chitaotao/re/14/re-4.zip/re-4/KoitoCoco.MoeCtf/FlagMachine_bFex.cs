namespace KoitoCoco.MoeCtf;

public class FlagMachine_bFex : FlagMachine_oAXR
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15022903291710455421uL);
	}
}
