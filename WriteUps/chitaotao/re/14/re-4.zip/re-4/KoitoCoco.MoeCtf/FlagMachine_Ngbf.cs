namespace KoitoCoco.MoeCtf;

public class FlagMachine_Ngbf : FlagMachine_kGVS
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17385776268506256751uL);
	}
}
