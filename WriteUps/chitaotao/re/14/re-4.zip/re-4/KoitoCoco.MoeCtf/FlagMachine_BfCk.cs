namespace KoitoCoco.MoeCtf;

public class FlagMachine_BfCk : FlagMachine_gBvB
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6505830181745270996L);
	}
}
