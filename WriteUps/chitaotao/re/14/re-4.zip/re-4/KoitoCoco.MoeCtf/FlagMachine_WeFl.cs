namespace KoitoCoco.MoeCtf;

public class FlagMachine_WeFl : FlagMachine_vPzi
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4839834371792628676L);
	}
}
