namespace KoitoCoco.MoeCtf;

public class FlagMachine_oMft : FlagMachine_OGTD
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12093711175419281047uL);
	}
}
