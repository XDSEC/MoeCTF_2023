namespace KoitoCoco.MoeCtf;

public class FlagMachine_nfxY : FlagMachine_yLna
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 559172260037198871L);
	}
}
