namespace KoitoCoco.MoeCtf;

public class FlagMachine_ziRq : FlagMachine_KdSU
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 487507261196410044L);
	}
}
