namespace KoitoCoco.MoeCtf;

public class FlagMachine_CDIU : FlagMachine_Euly
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8184020135371082747L);
	}
}
