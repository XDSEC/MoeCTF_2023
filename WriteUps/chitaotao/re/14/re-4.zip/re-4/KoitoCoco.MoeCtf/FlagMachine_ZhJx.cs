namespace KoitoCoco.MoeCtf;

public class FlagMachine_ZhJx : FlagMachine_CeIt
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5768494684887583698L);
	}
}
