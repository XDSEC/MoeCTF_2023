namespace KoitoCoco.MoeCtf;

public class FlagMachine_Ewpm : FlagMachine_uyJl
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14504226048355231446uL);
	}
}
