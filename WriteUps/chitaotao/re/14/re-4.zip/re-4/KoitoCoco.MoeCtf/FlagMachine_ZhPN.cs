namespace KoitoCoco.MoeCtf;

public class FlagMachine_ZhPN : FlagMachine_zffN
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9292811579580065009uL);
	}
}
