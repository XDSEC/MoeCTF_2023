namespace KoitoCoco.MoeCtf;

public class FlagMachine_KBPe : FlagMachine_AHLe
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7327811115415081540L);
	}
}
