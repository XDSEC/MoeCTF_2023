namespace KoitoCoco.MoeCtf;

public class FlagMachine_tALx : FlagMachine_mSkI
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 730474939637581579L);
	}
}
