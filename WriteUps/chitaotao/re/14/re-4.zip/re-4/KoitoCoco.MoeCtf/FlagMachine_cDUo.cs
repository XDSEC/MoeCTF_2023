namespace KoitoCoco.MoeCtf;

public class FlagMachine_cDUo : FlagMachine_uPAk
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4074986566424178513L);
	}
}
