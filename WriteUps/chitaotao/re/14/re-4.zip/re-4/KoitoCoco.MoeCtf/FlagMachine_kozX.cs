namespace KoitoCoco.MoeCtf;

public class FlagMachine_kozX : FlagMachine_DEjh
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3318084496947963784L);
	}
}
