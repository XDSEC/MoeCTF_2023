namespace KoitoCoco.MoeCtf;

public class FlagMachine_Ziny : FlagMachine_yQnI
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16225568107435721644uL);
	}
}
