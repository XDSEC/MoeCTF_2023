namespace KoitoCoco.MoeCtf;

public class FlagMachine_eWRP : FlagMachine_Ayzf
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 116734539407157997L);
	}
}
