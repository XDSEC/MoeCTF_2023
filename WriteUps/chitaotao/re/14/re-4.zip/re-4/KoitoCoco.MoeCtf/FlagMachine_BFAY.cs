namespace KoitoCoco.MoeCtf;

public class FlagMachine_BFAY : FlagMachine_uUgk
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 815736901819924459L);
	}
}
