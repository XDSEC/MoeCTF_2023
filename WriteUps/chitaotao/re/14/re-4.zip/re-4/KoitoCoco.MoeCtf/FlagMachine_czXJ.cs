namespace KoitoCoco.MoeCtf;

public class FlagMachine_czXJ : FlagMachine_DKvi
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12352725792963518348uL);
	}
}
