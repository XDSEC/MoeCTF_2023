namespace KoitoCoco.MoeCtf;

public class FlagMachine_ycTE : FlagMachine_GLUL
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3908491029837087029L);
	}
}
