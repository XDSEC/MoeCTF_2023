namespace KoitoCoco.MoeCtf;

public class FlagMachine_pGQN : FlagMachine_UqiT
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16084634948283572756uL);
	}
}
