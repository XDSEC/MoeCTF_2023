namespace KoitoCoco.MoeCtf;

public class FlagMachine_ghPi : FlagMachine_pAFC
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1805199935269903203L);
	}
}
