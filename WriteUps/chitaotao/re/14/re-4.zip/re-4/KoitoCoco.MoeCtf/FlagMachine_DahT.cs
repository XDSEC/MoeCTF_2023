namespace KoitoCoco.MoeCtf;

public class FlagMachine_DahT : FlagMachine_QNip
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12162981162918972611uL);
	}
}
