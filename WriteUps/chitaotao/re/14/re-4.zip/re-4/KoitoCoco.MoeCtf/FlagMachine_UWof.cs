namespace KoitoCoco.MoeCtf;

public class FlagMachine_UWof : FlagMachine_jkmv
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14917625023329692954uL);
	}
}
