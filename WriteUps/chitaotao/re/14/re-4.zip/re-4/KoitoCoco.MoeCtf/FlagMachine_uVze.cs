namespace KoitoCoco.MoeCtf;

public class FlagMachine_uVze : FlagMachine_LxzA
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4662471842200677074L);
	}
}
