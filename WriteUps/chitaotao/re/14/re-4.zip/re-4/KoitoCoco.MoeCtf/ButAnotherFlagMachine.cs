using System;

namespace KoitoCoco.MoeCtf;

public class ButAnotherFlagMachine : FlagMachine
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((ulong)flag ^ 0x1551155115511551uL);
	}

	public override void VmeFlag(string token)
	{
		//Console.WriteLine("AAE-O-A-A-U-U-A- E-eee-ee-eee");
	}
}
