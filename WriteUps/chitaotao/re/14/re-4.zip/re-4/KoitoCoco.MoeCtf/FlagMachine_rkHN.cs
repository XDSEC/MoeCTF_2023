namespace KoitoCoco.MoeCtf;

public class FlagMachine_rkHN : FlagMachine_JxHA
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6159101828618736217L);
	}
}
