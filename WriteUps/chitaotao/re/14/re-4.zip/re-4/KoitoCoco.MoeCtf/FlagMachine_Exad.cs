namespace KoitoCoco.MoeCtf;

public class FlagMachine_Exad : FlagMachine_odNU
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 369784092890740049L);
	}
}
