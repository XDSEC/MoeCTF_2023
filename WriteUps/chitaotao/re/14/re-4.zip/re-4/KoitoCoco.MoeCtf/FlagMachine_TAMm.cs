namespace KoitoCoco.MoeCtf;

public class FlagMachine_TAMm : FlagMachine_FtxR
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7219390893638634126L);
	}
}
