namespace KoitoCoco.MoeCtf;

public class FlagMachine_NGuU : FlagMachine_UqKf
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13506578535172374181uL);
	}
}
