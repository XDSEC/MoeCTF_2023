namespace KoitoCoco.MoeCtf;

public class FlagMachine_rkNv : FlagMachine_YZxV
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11395620801904772126uL);
	}
}
