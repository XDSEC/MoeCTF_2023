namespace KoitoCoco.MoeCtf;

public class FlagMachine_PGFI : FlagMachine_dAdd
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2671604459143374365L);
	}
}
