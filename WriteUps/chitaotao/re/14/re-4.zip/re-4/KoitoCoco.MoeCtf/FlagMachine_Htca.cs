namespace KoitoCoco.MoeCtf;

public class FlagMachine_Htca : FlagMachine_Ciew
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 494851808800095106L);
	}
}
