namespace KoitoCoco.MoeCtf;

public class FlagMachine_eYIR : FlagMachine_DXJW
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8469962402440530802L);
	}
}
