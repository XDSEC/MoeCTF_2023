namespace KoitoCoco.MoeCtf;

public class FlagMachine_zIjV : FlagMachine_Wlwn
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12825083218630428978uL);
	}
}
