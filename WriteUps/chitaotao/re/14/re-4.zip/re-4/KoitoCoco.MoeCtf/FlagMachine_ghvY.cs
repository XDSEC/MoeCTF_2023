namespace KoitoCoco.MoeCtf;

public class FlagMachine_ghvY : FlagMachine_vmXq
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13687873514099180489uL);
	}
}
