namespace KoitoCoco.MoeCtf;

public class FlagMachine_ZIgz : FlagMachine_Wers
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2045475765287665105L);
	}
}
