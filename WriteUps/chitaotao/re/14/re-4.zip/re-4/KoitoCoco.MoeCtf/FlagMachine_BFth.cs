namespace KoitoCoco.MoeCtf;

public class FlagMachine_BFth : FlagMachine_qCBH
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5277741133423249799L);
	}
}
