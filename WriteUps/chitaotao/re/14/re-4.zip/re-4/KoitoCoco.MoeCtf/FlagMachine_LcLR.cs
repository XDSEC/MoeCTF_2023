namespace KoitoCoco.MoeCtf;

public class FlagMachine_LcLR : FlagMachine_Cjhh
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5700960381060220880L);
	}
}
