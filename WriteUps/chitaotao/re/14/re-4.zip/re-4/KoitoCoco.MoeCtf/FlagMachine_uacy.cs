namespace KoitoCoco.MoeCtf;

public class FlagMachine_uacy : FlagMachine_XDRq
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8332304411792542617L);
	}
}
