namespace KoitoCoco.MoeCtf;

public class FlagMachine_bfbs : FlagMachine_duvg
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9952096965137082065uL);
	}
}
