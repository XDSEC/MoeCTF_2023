namespace KoitoCoco.MoeCtf;

public class FlagMachine_lcLQ : FlagMachine_wsWg
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17841169411828627100uL);
	}
}
