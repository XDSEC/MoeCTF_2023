namespace KoitoCoco.MoeCtf;

public class FlagMachine_PgvC : FlagMachine_qKKX
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2676525414725591392L);
	}
}
