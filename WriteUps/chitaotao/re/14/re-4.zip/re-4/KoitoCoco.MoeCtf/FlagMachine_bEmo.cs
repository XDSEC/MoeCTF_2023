namespace KoitoCoco.MoeCtf;

public class FlagMachine_bEmo : FlagMachine_Zlry
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 762190303604444156L);
	}
}
