namespace KoitoCoco.MoeCtf;

public class FlagMachine_rKWb : FlagMachine_doYd
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12735777047753545428uL);
	}
}
