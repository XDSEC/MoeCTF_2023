namespace KoitoCoco.MoeCtf;

public class FlagMachine_cdmr : FlagMachine_uIzB
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7595783368896053062L);
	}
}
