namespace KoitoCoco.MoeCtf;

public class FlagMachine_lCND : FlagMachine_biwX
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3670945085626124330L);
	}
}
