namespace KoitoCoco.MoeCtf;

public class FlagMachine_oLPJ : FlagMachine_pRaH
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11421719166089948255uL);
	}
}
