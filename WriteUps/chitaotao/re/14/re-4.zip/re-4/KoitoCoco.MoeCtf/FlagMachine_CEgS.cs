namespace KoitoCoco.MoeCtf;

public class FlagMachine_CEgS : FlagMachine_ZKpx
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13567169098929798571uL);
	}
}
