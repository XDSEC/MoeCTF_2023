namespace KoitoCoco.MoeCtf;

public class FlagMachine_wedY : FlagMachine_KLee
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11410906271671849491uL);
	}
}
