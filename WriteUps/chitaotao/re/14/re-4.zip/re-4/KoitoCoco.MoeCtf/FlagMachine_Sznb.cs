namespace KoitoCoco.MoeCtf;

public class FlagMachine_Sznb : FlagMachine_sxPQ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11328321926018021158uL);
	}
}
