namespace KoitoCoco.MoeCtf;

public class FlagMachine_kCsu : FlagMachine_aODR
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5310867073287288689L);
	}
}
