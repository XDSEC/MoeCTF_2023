namespace KoitoCoco.MoeCtf;

public class FlagMachine_ZhnC : FlagMachine_WQwm
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1403282997239601272L);
	}
}
