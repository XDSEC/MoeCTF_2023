namespace KoitoCoco.MoeCtf;

public class FlagMachine_EyNq : FlagMachine_vzPH
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6220349234728938699L);
	}
}
