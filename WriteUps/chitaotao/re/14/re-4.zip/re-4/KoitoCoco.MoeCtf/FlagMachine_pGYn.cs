namespace KoitoCoco.MoeCtf;

public class FlagMachine_pGYn : FlagMachine_VjRe
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9538644042696712473uL);
	}
}
