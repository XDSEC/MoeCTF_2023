namespace KoitoCoco.MoeCtf;

public class FlagMachine_Hrca : FlagMachine_HcWu
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11589140702715289427uL);
	}
}
