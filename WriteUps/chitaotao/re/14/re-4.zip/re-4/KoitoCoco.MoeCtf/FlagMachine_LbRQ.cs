namespace KoitoCoco.MoeCtf;

public class FlagMachine_LbRQ : FlagMachine_uDyp
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5087814205566808134L);
	}
}
