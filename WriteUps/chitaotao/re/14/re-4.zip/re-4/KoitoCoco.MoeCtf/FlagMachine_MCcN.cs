namespace KoitoCoco.MoeCtf;

public class FlagMachine_MCcN : FlagMachine_izMI
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1326942592519360809L);
	}
}
