namespace KoitoCoco.MoeCtf;

public class FlagMachine_rkvj : FlagMachine_agmy
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9841483310056871149uL);
	}
}
