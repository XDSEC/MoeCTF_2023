namespace KoitoCoco.MoeCtf;

public class FlagMachine_LDjJ : FlagMachine_USuz
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14359834904023974113uL);
	}
}
