namespace KoitoCoco.MoeCtf;

public class FlagMachine_yBvU : FlagMachine_bmlD
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12022815869571237944uL);
	}
}
