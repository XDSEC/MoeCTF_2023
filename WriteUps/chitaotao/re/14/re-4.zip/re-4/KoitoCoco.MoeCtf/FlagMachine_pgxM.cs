namespace KoitoCoco.MoeCtf;

public class FlagMachine_pgxM : FlagMachine_bgKd
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8029718855870049869L);
	}
}
public class FlagMachine_pGXM : FlagMachine_ThVL
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9337505616862085147uL);
	}
}
