namespace KoitoCoco.MoeCtf;

public class FlagMachine_dtLi : FlagMachine_UTFR
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17253888096211597630uL);
	}
}
