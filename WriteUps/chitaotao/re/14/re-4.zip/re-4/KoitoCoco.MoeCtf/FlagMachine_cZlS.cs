namespace KoitoCoco.MoeCtf;

public class FlagMachine_cZlS : FlagMachine_jbgW
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1010985355528575240L);
	}
}
