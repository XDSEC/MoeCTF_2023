namespace KoitoCoco.MoeCtf;

public class FlagMachine_jCFn : FlagMachine_DVnN
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7379598149346693583L);
	}
}
