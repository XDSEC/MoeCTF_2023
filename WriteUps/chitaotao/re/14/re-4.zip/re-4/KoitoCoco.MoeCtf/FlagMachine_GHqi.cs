namespace KoitoCoco.MoeCtf;

public class FlagMachine_GHqi : FlagMachine_VSTP
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4645557532734923567L);
	}
}
