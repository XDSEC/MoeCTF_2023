namespace KoitoCoco.MoeCtf;

public class FlagMachine_lcAH : FlagMachine_SCOT
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9539130925803362378uL);
	}
}
