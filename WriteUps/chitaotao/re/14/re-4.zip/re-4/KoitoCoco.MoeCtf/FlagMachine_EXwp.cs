namespace KoitoCoco.MoeCtf;

public class FlagMachine_EXwp : FlagMachine_akpk
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 233844346180261330L);
	}
}
