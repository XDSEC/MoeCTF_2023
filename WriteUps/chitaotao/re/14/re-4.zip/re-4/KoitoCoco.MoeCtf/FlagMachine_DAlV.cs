namespace KoitoCoco.MoeCtf;

public class FlagMachine_DAlV : FlagMachine_gMeM
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3544397683289707960L);
	}
}
