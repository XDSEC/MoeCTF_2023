namespace KoitoCoco.MoeCtf;

public class FlagMachine_pgoy : FlagMachine_mAzV
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15910921764063354273uL);
	}
}
