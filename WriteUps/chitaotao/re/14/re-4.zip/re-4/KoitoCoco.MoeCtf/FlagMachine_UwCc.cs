namespace KoitoCoco.MoeCtf;

public class FlagMachine_UwCc : FlagMachine_HhNw
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8202289820524797976L);
	}
}
