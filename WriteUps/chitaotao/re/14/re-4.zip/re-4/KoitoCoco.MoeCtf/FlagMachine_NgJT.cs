namespace KoitoCoco.MoeCtf;

public class FlagMachine_NgJT : FlagMachine_LdmA
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4628003861221453720L);
	}
}
