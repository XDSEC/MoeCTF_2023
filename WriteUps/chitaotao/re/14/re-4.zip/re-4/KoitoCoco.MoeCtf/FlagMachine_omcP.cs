namespace KoitoCoco.MoeCtf;

public class FlagMachine_omcP : FlagMachine_OSzS
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11856745046774239745uL);
	}
}
public class FlagMachine_OMCP : FlagMachine_wIMk
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7146135051080218639L);
	}
}
