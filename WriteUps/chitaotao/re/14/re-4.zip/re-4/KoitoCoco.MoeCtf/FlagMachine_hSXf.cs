namespace KoitoCoco.MoeCtf;

public class FlagMachine_hSXf : FlagMachine_uAOv
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6427522955338270659L);
	}
}
