namespace KoitoCoco.MoeCtf;

public class FlagMachine_hSyh : FlagMachine_jhUl
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4729271753192006820L);
	}
}
