namespace KoitoCoco.MoeCtf;

public class FlagMachine_HrqK : FlagMachine_hdfM
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8083676928659563212L);
	}
}
