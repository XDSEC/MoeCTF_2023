namespace KoitoCoco.MoeCtf;

public class FlagMachine_TaCD : FlagMachine_sTaY
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8120177554264827649L);
	}
}
