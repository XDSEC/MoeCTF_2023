namespace KoitoCoco.MoeCtf;

public class FlagMachine_nhDZ : FlagMachine_itmI
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3507403089712904476L);
	}
}
