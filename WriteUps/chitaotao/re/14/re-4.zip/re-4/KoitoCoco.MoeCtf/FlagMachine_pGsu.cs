namespace KoitoCoco.MoeCtf;

public class FlagMachine_pGsu : FlagMachine_AtEx
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11346012085067759076uL);
	}
}
