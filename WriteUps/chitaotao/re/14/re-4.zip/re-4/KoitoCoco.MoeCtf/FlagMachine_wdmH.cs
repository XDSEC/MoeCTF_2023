namespace KoitoCoco.MoeCtf;

public class FlagMachine_wdmH : FlagMachine_aZFo
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11907553371250383054uL);
	}
}
