namespace KoitoCoco.MoeCtf;

public class FlagMachine_YCEj : FlagMachine_pGsJ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17875852642212297907uL);
	}
}
