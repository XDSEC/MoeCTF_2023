namespace KoitoCoco.MoeCtf;

public class FlagMachine_gIPn : FlagMachine_ZhCI
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6922693515529306829L);
	}
}
