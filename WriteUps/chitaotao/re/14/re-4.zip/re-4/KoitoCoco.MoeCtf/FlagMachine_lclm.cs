namespace KoitoCoco.MoeCtf;

public class FlagMachine_lclm : FlagMachine_OxWu
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 833173173336146940L);
	}
}
