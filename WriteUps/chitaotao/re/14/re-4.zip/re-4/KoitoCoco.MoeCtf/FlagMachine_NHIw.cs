namespace KoitoCoco.MoeCtf;

public class FlagMachine_NHIw : FlagMachine_eZqw
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7084864400100304944L);
	}
}
