namespace KoitoCoco.MoeCtf;

public class FlagMachine_GiOl : FlagMachine_ubui
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 10621458580798341036uL);
	}
}
