using System;
using System.Text;

namespace KoitoCoco.MoeCtf;

public class FakeFlagMachinePlus : ButAnotherFlagMachine
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)((ulong)flag ^ 0x7890A1B2C3D4E5F6uL));
	}

	public override void VmeFlag(string token)
	{
		base.VmeFlag(token);
		if (KoitoMagicalShop.IsRealFlag(Encoding.UTF8.GetBytes(token), Flag))
		{
			Console.WriteLine("Good Job!");
		}
	}
}
