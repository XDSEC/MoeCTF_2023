namespace KoitoCoco.MoeCtf;

public class FlagMachine_kBwc : FlagMachine_jYZJ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13449074730805999906uL);
	}
}
