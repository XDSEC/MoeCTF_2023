namespace KoitoCoco.MoeCtf;

public class FlagMachine_zHUK : FlagMachine_olTq
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 18221943009041070993uL);
	}
}
