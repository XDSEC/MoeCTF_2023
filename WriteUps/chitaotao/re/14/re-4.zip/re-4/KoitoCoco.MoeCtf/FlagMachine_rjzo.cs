namespace KoitoCoco.MoeCtf;

public class FlagMachine_rjzo : FlagMachine_HqEc
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4827095968124726336L);
	}
}
public class FlagMachine_RJZO : FlagMachine_duvg
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 37083000219967472L);
	}
}
