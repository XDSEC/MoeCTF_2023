namespace KoitoCoco.MoeCtf;

public class FlagMachine_RlaL : FlagMachine_nsZy
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16073217479930391275uL);
	}
}
