namespace KoitoCoco.MoeCtf;

public class FlagMachine_BELp : FlagMachine_HinT
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5875935866561742917L);
	}
}
