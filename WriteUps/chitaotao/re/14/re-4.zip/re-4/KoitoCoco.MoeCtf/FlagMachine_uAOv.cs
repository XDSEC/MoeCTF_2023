namespace KoitoCoco.MoeCtf;

public class FlagMachine_uAOv : FlagMachine_ysoN
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16751127292176954434uL);
	}
}
