namespace KoitoCoco.MoeCtf;

public class FlagMachine_uWOo : FlagMachine_KHFk
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2943925472917669139L);
	}
}
