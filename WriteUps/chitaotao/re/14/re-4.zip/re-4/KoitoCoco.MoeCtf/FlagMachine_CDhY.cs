namespace KoitoCoco.MoeCtf;

public class FlagMachine_CDhY : FlagMachine_bxeP
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9938667582746601463uL);
	}
}
