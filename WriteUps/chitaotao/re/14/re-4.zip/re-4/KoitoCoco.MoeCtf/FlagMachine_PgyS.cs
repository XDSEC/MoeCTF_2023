namespace KoitoCoco.MoeCtf;

public class FlagMachine_PgyS : FlagMachine_DRBh
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15901685861130693521uL);
	}
}
