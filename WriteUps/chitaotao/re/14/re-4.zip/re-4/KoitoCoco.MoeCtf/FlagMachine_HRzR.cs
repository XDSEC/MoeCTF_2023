namespace KoitoCoco.MoeCtf;

public class FlagMachine_HRzR : FlagMachine_pNQP
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6484911378935030187L);
	}
}
