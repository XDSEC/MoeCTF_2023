namespace KoitoCoco.MoeCtf;

public class FlagMachine_kbxO : FlagMachine_gyyf
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4048388352660936640L);
	}
}
public class FlagMachine_kBXO : FlagMachine_KxxT
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11079041043979960475uL);
	}
}
