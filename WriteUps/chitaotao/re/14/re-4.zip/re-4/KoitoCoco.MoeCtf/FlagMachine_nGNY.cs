namespace KoitoCoco.MoeCtf;

public class FlagMachine_nGNY : FlagMachine_YZuw
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5539398239199252040L);
	}
}
