namespace KoitoCoco.MoeCtf;

public class FlagMachine_eYzT : FlagMachine_wVRr
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 236904260926964298L);
	}
}
