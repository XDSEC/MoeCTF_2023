namespace KoitoCoco.MoeCtf;

public class FlagMachine_hSeW : FlagMachine_dzDZ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12352446517331320511uL);
	}
}
