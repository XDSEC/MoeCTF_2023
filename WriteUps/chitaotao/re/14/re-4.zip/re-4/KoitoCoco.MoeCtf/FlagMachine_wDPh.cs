namespace KoitoCoco.MoeCtf;

public class FlagMachine_wDPh : FlagMachine_mtnB
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1881720074753698580L);
	}
}
