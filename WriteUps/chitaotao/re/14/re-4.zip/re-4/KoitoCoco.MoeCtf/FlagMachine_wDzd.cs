namespace KoitoCoco.MoeCtf;

public class FlagMachine_wDzd : FlagMachine_JtDf
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1832671659644405867L);
	}
}
