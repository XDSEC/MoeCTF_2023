namespace KoitoCoco.MoeCtf;

public class FlagMachine_kCce : FlagMachine_oRHo
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7726259498564905226L);
	}
}
