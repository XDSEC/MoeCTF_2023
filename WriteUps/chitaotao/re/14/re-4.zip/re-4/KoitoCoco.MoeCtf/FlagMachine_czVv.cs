namespace KoitoCoco.MoeCtf;

public class FlagMachine_czVv : FlagMachine_gIpg
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 10002615041196961694uL);
	}
}
