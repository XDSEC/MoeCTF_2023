namespace KoitoCoco.MoeCtf;

public class FlagMachine_NgEf : FlagMachine_mDgi
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3197373853433081620L);
	}
}
