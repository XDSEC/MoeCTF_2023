namespace KoitoCoco.MoeCtf;

public class FlagMachine_jcJA : FlagMachine_JAmz
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13822465277138149107uL);
	}
}
