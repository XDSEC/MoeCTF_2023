namespace KoitoCoco.MoeCtf;

public class FlagMachine_NGQo : FlagMachine_uguC
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 501011685169332458L);
	}
}
