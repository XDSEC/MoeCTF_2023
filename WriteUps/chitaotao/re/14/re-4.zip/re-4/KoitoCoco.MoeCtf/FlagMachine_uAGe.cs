namespace KoitoCoco.MoeCtf;

public class FlagMachine_uAGe : FlagMachine_SEzJ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2140181501227905684L);
	}
}
