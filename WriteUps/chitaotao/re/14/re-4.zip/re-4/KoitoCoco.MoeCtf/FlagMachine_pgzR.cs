namespace KoitoCoco.MoeCtf;

public class FlagMachine_pgzR : FlagMachine_xZGa
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11916123575554766126uL);
	}
}
