namespace KoitoCoco.MoeCtf;

public class FlagMachine_hRdK : FlagMachine_zsjl
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16710026746982169529uL);
	}
}
