namespace KoitoCoco.MoeCtf;

public class FlagMachine_gIrt : FlagMachine_ixFK
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7569646405402921379L);
	}
}
