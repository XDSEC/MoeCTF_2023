namespace KoitoCoco.MoeCtf;

public class FlagMachine_pgGj : FlagMachine_YWnH
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8232103031728295981L);
	}
}
