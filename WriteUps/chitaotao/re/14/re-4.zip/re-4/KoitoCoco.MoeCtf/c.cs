namespace KoitoCoco.MoeCtf;

internal enum c
{
	CreateProcessDebugEvent = 3,
	CreateThreadDebugEvent = 2,
	ExceptionDebugEvent = 1,
	ExitProcessDebugEvent = 5,
	ExitThreadDebugEvent = 4,
	LoadDllDebugEvent = 6,
	OutputDebugStringEvent = 8,
	RipEvent = 9,
	UnloadDllDebugEvent = 7
}
