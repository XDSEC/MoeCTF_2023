namespace KoitoCoco.MoeCtf;

public class FlagMachine_EWsw : FlagMachine_xMCl
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2921356420738327865L);
	}
}
