namespace KoitoCoco.MoeCtf;

public class FlagMachine_kcXc : FlagMachine_ZoXO
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 18290353532171333118uL);
	}
}
