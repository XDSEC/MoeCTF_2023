namespace KoitoCoco.MoeCtf;

public class FlagMachine_uXfL : FlagMachine_DquQ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17138451852918034040uL);
	}
}
