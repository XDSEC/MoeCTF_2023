namespace KoitoCoco.MoeCtf;

public class FlagMachine_gIzp : FlagMachine_ftXK
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13829580597305378631uL);
	}
}
