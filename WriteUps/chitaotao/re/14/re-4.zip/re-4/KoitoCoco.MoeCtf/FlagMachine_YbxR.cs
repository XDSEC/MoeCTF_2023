namespace KoitoCoco.MoeCtf;

public class FlagMachine_YbxR : FlagMachine_UVOk
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17551878330832772560uL);
	}
}
