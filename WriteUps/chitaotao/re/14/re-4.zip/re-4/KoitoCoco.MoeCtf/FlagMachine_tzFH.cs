namespace KoitoCoco.MoeCtf;

public class FlagMachine_tzFH : FlagMachine_EEVk
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2518907080147793535L);
	}
}
