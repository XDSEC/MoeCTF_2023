namespace KoitoCoco.MoeCtf;

public class FlagMachine_rJHa : FlagMachine_PbPI
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 83548734775045621L);
	}
}
