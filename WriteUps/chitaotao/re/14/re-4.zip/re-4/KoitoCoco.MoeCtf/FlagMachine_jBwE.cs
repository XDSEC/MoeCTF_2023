namespace KoitoCoco.MoeCtf;

public class FlagMachine_jBwE : FlagMachine_iOVL
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 763556124796293272L);
	}
}
