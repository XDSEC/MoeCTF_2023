namespace KoitoCoco.MoeCtf;

public class FlagMachine_bFiC : FlagMachine_MZuA
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16764201052220969183uL);
	}
}
