namespace KoitoCoco.MoeCtf;

public class FlagMachine_ezIB : FlagMachine_fmea
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 762298399321481669L);
	}
}
