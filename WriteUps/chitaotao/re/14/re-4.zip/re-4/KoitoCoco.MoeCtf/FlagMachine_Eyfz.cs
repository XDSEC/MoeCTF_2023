namespace KoitoCoco.MoeCtf;

public class FlagMachine_Eyfz : FlagMachine_kMAd
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16108661326511647876uL);
	}
}
