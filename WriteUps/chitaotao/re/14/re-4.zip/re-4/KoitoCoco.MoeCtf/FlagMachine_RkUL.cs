namespace KoitoCoco.MoeCtf;

public class FlagMachine_RkUL : FlagMachine_PLhr
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7161871898492126141L);
	}
}
