namespace KoitoCoco.MoeCtf;

public class FlagMachine_uxFR : FlagMachine_VArE
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14134016985669927717uL);
	}
}
