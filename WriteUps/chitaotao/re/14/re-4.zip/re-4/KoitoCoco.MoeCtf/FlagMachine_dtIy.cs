namespace KoitoCoco.MoeCtf;

public class FlagMachine_dtIy : FlagMachine_GeSV
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3037273786369678948L);
	}
}
