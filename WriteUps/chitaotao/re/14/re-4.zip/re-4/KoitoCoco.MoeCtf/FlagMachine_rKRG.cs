namespace KoitoCoco.MoeCtf;

public class FlagMachine_rKRG : FlagMachine_xPcc
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14343902031850095166uL);
	}
}
