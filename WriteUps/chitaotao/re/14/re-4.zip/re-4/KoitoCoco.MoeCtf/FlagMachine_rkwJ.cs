namespace KoitoCoco.MoeCtf;

public class FlagMachine_rkwJ : FlagMachine_MzPq
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5625169885726525673L);
	}
}
