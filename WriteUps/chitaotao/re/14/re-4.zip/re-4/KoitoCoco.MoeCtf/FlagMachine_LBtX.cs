namespace KoitoCoco.MoeCtf;

public class FlagMachine_LBtX : FlagMachine_JzrX
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 10483589833703954486uL);
	}
}
