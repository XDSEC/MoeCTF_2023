namespace KoitoCoco.MoeCtf;

public class FlagMachine_BeQc : FlagMachine_eKNz
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16568651146861682571uL);
	}
}
