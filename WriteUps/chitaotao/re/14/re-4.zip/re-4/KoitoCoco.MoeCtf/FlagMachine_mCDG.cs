namespace KoitoCoco.MoeCtf;

public class FlagMachine_mCDG : FlagMachine_Hrca
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8618699448636720124L);
	}
}
