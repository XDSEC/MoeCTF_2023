namespace KoitoCoco.MoeCtf;

public class FlagMachine_KBLP : FlagMachine_Euly
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 10766511744945922067uL);
	}
}
