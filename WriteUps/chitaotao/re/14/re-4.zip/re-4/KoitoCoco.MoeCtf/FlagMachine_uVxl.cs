namespace KoitoCoco.MoeCtf;

public class FlagMachine_uVxl : FlagMachine_UJWs
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3785640712016524247L);
	}
}
