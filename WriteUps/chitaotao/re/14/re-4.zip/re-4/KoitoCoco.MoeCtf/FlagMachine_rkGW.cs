namespace KoitoCoco.MoeCtf;

public class FlagMachine_rkGW : FlagMachine_PtND
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2814141591206564413L);
	}
}
