namespace KoitoCoco.MoeCtf;

public class FlagMachine_Rkyq : FlagMachine_hSyh
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4737210149103717389L);
	}
}
