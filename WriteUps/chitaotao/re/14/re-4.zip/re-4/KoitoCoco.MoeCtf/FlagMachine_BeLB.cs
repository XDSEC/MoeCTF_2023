namespace KoitoCoco.MoeCtf;

public class FlagMachine_BeLB : FlagMachine_axki
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4756541812282706033L);
	}
}
