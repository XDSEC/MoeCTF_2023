namespace KoitoCoco.MoeCtf;

public class FlagMachine_cdsj : FlagMachine_NPyb
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4245249554937651096L);
	}
}
