namespace KoitoCoco.MoeCtf;

public class FlagMachine_NFyH : FlagMachine_NJJb
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4572841321856661272L);
	}
}
