namespace KoitoCoco.MoeCtf;

public class FlagMachine_DAHF : FlagMachine_ZCNN
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14246054272465900002uL);
	}
}
