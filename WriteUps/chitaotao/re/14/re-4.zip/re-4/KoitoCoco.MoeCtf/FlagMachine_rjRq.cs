namespace KoitoCoco.MoeCtf;

public class FlagMachine_rjRq : FlagMachine_yXLP
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14411477145718065462uL);
	}
}
