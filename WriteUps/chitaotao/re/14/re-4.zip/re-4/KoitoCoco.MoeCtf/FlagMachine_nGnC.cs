namespace KoitoCoco.MoeCtf;

public class FlagMachine_nGnC : FlagMachine_DUBZ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14692021942641841342uL);
	}
}
