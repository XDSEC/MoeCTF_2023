namespace KoitoCoco.MoeCtf;

public class FlagMachine_pgXF : FlagMachine_JeBQ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 10900670609916927715uL);
	}
}
