namespace KoitoCoco.MoeCtf;

public class FlagMachine_hsFX : FlagMachine_cxvz
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4950087774766076803L);
	}
}
