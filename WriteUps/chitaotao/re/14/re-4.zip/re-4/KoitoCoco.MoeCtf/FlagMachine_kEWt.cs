namespace KoitoCoco.MoeCtf;

public class FlagMachine_kEWt : FlagMachine_KPel
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 582281389947780909L);
	}
}
