namespace KoitoCoco.MoeCtf;

public class FlagMachine_NGYA : FlagMachine_uXza
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3298747345376904659L);
	}
}
