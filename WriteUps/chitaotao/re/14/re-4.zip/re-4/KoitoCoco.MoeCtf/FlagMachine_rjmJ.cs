namespace KoitoCoco.MoeCtf;

public class FlagMachine_rjmJ : FlagMachine_qfxZ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8904076159474939696L);
	}
}
