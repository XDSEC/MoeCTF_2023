namespace KoitoCoco.MoeCtf;

public class FlagMachine_lcEi : FlagMachine_pbUx
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13549082494919490019uL);
	}
}
