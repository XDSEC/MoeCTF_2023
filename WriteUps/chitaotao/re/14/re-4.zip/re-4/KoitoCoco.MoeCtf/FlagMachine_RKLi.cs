namespace KoitoCoco.MoeCtf;

public class FlagMachine_RKLi : FlagMachine_chZZ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 18276771914861377033uL);
	}
}
