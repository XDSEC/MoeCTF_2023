namespace KoitoCoco.MoeCtf;

public class FlagMachine_bEvD : FlagMachine_EMgK
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5670831772582249541L);
	}
}
