namespace KoitoCoco.MoeCtf;

public class FlagMachine_ezGr : FlagMachine_GXbh
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17403840586801895741uL);
	}
}
