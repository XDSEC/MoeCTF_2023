namespace KoitoCoco.MoeCtf;

public class FlagMachine_EySk : FlagMachine_IBKm
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13629317465391829537uL);
	}
}
