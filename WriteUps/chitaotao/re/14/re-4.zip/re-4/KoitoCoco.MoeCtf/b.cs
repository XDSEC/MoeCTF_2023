using System.Runtime.InteropServices;

namespace KoitoCoco.MoeCtf;

internal struct b
{
	[MarshalAs(UnmanagedType.I4)]
	public c dwDebugEventCode;

	public int dwProcessId;

	public int dwThreadId;

	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 1024)]
	public byte[] bytes;
}
