namespace KoitoCoco.MoeCtf;

public class FlagMachine_mcfI : FlagMachine_TBYP
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 12905237279287934875uL);
	}
}
