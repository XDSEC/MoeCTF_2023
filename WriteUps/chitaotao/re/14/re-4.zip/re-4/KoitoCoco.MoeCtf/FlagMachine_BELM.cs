namespace KoitoCoco.MoeCtf;

public class FlagMachine_BELM : FlagMachine_QNSh
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 9025293825988021927L);
	}
}
