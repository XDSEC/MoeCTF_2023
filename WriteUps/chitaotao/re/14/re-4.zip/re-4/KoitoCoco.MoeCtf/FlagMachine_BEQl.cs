namespace KoitoCoco.MoeCtf;

public class FlagMachine_BEQl : FlagMachine_ApiJ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 18290229107723044476uL);
	}
}
