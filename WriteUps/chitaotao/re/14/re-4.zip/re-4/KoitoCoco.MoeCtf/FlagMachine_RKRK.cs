namespace KoitoCoco.MoeCtf;

public class FlagMachine_RKRK : FlagMachine_eEKJ
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8942133957622195282L);
	}
}
