namespace KoitoCoco.MoeCtf;

public class FlagMachine_MCWx : FlagMachine_KYJp
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7237957825255531736L);
	}
}
