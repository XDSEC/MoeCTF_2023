namespace KoitoCoco.MoeCtf;

public class FlagMachine_RlAE : FlagMachine_pvOL
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14629512498469131118uL);
	}
}
