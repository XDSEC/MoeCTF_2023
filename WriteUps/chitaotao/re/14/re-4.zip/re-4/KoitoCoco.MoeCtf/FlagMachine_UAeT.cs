namespace KoitoCoco.MoeCtf;

public class FlagMachine_UAeT : FlagMachine_bGmM
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13782139737838299488uL);
	}
}
