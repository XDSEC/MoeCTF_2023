namespace KoitoCoco.MoeCtf;

public class FlagMachine_jBFZ : FlagMachine_KZwk
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17346845314331512427uL);
	}
}
