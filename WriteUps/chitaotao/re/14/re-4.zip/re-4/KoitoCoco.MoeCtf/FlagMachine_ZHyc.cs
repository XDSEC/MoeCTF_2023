namespace KoitoCoco.MoeCtf;

public class FlagMachine_ZHyc : FlagMachine_oxkj
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 10988026691598784206uL);
	}
}
