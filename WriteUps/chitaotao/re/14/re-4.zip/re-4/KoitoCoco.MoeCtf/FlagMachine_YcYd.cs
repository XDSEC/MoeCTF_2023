namespace KoitoCoco.MoeCtf;

public class FlagMachine_YcYd : FlagMachine_OfPP
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13004256916719199402uL);
	}
}
