namespace KoitoCoco.MoeCtf;

public class FlagMachine_lCQx : FlagMachine_rEAV
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11102309756164489083uL);
	}
}
