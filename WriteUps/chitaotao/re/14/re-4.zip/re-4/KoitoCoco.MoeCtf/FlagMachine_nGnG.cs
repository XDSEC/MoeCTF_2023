namespace KoitoCoco.MoeCtf;

public class FlagMachine_nGnG : FlagMachine_NzUP
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13005111327176550062uL);
	}
}
