namespace KoitoCoco.MoeCtf;

public class FlagMachine_RkLE : FlagMachine_qtEb
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16918907429842445034uL);
	}
}
