namespace KoitoCoco.MoeCtf;

public class FlagMachine_tAng : FlagMachine_yawY
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6779050151608076488L);
	}
}
