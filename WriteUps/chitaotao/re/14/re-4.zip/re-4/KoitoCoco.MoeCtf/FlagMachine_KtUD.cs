namespace KoitoCoco.MoeCtf;

public class FlagMachine_KtUD : FlagMachine_pAFC
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7709520379764155315L);
	}
}
