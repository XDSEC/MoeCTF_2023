namespace KoitoCoco.MoeCtf;

public class FlagMachine_uwDl : FlagMachine_oTTg
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3773101454616039742L);
	}
}
