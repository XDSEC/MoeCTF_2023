namespace KoitoCoco.MoeCtf;

public class FlagMachine_kBwm : FlagMachine_TrlC
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1468923822481613454L);
	}
}
