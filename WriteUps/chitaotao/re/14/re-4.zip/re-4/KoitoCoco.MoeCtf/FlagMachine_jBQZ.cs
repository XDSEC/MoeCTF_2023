namespace KoitoCoco.MoeCtf;

public class FlagMachine_jBQZ : FlagMachine_fdXp
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8845589874619596750L);
	}
}
