namespace KoitoCoco.MoeCtf;

public class FlagMachine_JbfL : FlagMachine_WmkM
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17221978874132892004uL);
	}
}
