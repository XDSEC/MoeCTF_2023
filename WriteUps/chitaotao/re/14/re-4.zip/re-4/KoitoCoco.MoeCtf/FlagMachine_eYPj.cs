namespace KoitoCoco.MoeCtf;

public class FlagMachine_eYPj : FlagMachine_DIBw
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 14253964313510955289uL);
	}
}
