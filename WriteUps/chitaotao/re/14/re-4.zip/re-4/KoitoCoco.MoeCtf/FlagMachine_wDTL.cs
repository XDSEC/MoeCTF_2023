namespace KoitoCoco.MoeCtf;

public class FlagMachine_wDTL : FlagMachine_OAYg
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 110011719662097094L);
	}
}
