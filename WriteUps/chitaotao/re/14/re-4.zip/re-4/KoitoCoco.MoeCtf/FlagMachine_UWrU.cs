namespace KoitoCoco.MoeCtf;

public class FlagMachine_UWrU : FlagMachine_ZKPg
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 11676856835023653538uL);
	}
}
