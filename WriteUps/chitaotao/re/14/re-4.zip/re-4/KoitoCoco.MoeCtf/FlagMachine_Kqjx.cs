namespace KoitoCoco.MoeCtf;

public class FlagMachine_Kqjx : FlagMachine_LmMk
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2263421424266950975L);
	}
}
