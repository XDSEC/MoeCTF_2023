namespace KoitoCoco.MoeCtf;

public class FlagMachine_MCKg : FlagMachine_bmlD
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16396208830053716406uL);
	}
}
