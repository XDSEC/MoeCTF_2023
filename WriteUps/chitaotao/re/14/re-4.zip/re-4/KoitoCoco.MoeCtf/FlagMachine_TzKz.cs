namespace KoitoCoco.MoeCtf;

public class FlagMachine_TzKz : FlagMachine_wSxH
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1886043587354200583L);
	}
}
