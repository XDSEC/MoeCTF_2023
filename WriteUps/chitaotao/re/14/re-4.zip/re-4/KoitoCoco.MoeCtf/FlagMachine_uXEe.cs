namespace KoitoCoco.MoeCtf;

public class FlagMachine_uXEe : FlagMachine_FJAg
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13104320109881913279uL);
	}
}
