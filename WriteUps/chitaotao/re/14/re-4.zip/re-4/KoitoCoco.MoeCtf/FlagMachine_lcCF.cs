namespace KoitoCoco.MoeCtf;

public class FlagMachine_lcCF : FlagMachine_kfhN
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17836050315826268269uL);
	}
}
