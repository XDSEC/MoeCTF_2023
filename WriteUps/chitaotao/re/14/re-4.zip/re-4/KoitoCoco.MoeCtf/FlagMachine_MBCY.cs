namespace KoitoCoco.MoeCtf;

public class FlagMachine_MBCY : FlagMachine_OxWu
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1827236178295385201L);
	}
}
