namespace KoitoCoco.MoeCtf;

public class FlagMachine_gIbr : FlagMachine_sfWb
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2861551102731978871L);
	}
}
