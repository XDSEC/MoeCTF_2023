namespace KoitoCoco.MoeCtf;

public class FlagMachine_McJH : FlagMachine_FyLo
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17234577995133420593uL);
	}
}
