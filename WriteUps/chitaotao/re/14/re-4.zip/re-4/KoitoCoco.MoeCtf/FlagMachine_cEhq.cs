namespace KoitoCoco.MoeCtf;

public class FlagMachine_cEhq : FlagMachine_DOcv
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 738003161058757899L);
	}
}
