namespace KoitoCoco.MoeCtf;

public class FlagMachine_OlPv : FlagMachine_Pqrc
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 16744188926531374233uL);
	}
}
