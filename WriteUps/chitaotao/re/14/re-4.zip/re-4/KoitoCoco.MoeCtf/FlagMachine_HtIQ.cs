namespace KoitoCoco.MoeCtf;

public class FlagMachine_HtIQ : FlagMachine_Yztr
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2400467278518297835L);
	}
}
