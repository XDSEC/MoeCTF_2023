namespace KoitoCoco.MoeCtf;

public class FlagMachine_oLPz : FlagMachine_zVjB
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 8068681772662746752L);
	}
}
