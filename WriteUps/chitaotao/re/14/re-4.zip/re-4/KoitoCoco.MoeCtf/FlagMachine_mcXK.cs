namespace KoitoCoco.MoeCtf;

public class FlagMachine_mcXK : FlagMachine_kBEF
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17137782548504200815uL);
	}
}
