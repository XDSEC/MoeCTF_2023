namespace KoitoCoco.MoeCtf;

public class FlagMachine_jBud : FlagMachine_zkla
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3157059393912474559L);
	}
}
