namespace KoitoCoco.MoeCtf;

public class FlagMachine_LBvo : FlagMachine_WvqD
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17577858576353278630uL);
	}
}
