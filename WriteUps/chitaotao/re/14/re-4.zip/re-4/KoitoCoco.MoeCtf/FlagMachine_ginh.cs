namespace KoitoCoco.MoeCtf;

public class FlagMachine_ginh : FlagMachine_ylep
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4415679163140133832L);
	}
}
