namespace KoitoCoco.MoeCtf;

public class FlagMachine_DaeX : FlagMachine_bndM
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1299681345718912298L);
	}
}
