namespace KoitoCoco.MoeCtf;

public class FlagMachine_zhql : FlagMachine_oxkj
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 5685616808151892144L);
	}
}
