namespace KoitoCoco.MoeCtf;

public class FlagMachine_pGqx : FlagMachine_sLhY
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1644800829254539866L);
	}
}
