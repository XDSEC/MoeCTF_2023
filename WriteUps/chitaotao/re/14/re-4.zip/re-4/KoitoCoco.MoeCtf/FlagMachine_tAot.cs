namespace KoitoCoco.MoeCtf;

public class FlagMachine_tAot : FlagMachine_Wogz
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15109019474321389021uL);
	}
}
