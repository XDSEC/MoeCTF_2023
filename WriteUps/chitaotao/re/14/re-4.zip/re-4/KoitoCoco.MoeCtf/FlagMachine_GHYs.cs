namespace KoitoCoco.MoeCtf;

public class FlagMachine_GHYs : FlagMachine_ZDyH
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 2312539165476798744L);
	}
}
