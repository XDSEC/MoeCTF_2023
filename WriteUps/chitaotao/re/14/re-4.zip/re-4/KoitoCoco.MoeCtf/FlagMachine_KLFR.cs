namespace KoitoCoco.MoeCtf;

public class FlagMachine_KLFR : FlagMachine_usII
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 6193086231099992479L);
	}
}
