namespace KoitoCoco.MoeCtf;

public class FlagMachine_jcij : FlagMachine_DfWt
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 15123442434339598934uL);
	}
}
