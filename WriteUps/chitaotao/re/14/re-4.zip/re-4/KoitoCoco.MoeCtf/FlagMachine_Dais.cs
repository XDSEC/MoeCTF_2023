namespace KoitoCoco.MoeCtf;

public class FlagMachine_Dais : FlagMachine_doMR
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 631961252214898187L);
	}
}
