namespace KoitoCoco.MoeCtf;

public class FlagMachine_nGsF : FlagMachine_oeGF
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 3794165370265117822L);
	}
}
