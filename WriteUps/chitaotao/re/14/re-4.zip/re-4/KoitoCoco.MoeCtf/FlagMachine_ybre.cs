namespace KoitoCoco.MoeCtf;

public class FlagMachine_ybre : FlagMachine_AQcS
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 13820771172908627664uL);
	}
}
