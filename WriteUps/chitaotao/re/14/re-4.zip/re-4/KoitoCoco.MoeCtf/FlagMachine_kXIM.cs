namespace KoitoCoco.MoeCtf;

public class FlagMachine_kXIM : FlagMachine_LvvN
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1393777445679491501L);
	}
}
