namespace KoitoCoco.MoeCtf;

public class FlagMachine_JBeW : FlagMachine_sSRL
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 17699094087497604527uL);
	}
}
