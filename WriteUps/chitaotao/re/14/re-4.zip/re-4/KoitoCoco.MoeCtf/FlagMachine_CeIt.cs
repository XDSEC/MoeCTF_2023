namespace KoitoCoco.MoeCtf;

public class FlagMachine_CeIt : FlagMachine_GuKH
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 805242521575944444L);
	}
}
