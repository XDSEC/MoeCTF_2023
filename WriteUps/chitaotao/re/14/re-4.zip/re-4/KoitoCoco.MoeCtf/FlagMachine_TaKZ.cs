namespace KoitoCoco.MoeCtf;

public class FlagMachine_TaKZ : FlagMachine_Unti
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 1649733246141376441L);
	}
}
