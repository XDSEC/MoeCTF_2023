namespace KoitoCoco.MoeCtf;

public class FlagMachine_rJln : FlagMachine_ZwoU
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 7052209178716854732L);
	}
}
