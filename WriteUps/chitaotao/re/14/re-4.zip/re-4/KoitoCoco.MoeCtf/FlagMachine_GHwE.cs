namespace KoitoCoco.MoeCtf;

public class FlagMachine_GHwE : FlagMachine_dKaM
{
	public override void SetFlag(dynamic flag)
	{
		base.SetFlag((object)(byte[])flag);
		Flag = Xorrrrr.xor(Flag, 4012198329526668357L);
	}
}
